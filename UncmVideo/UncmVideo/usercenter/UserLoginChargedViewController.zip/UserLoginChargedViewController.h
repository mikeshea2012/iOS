//
// Created by xinyingtiyu on 13-3-19.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import <Foundation/Foundation.h>


@interface UserLoginChargedViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@end