//
// Created by xinyingtiyu on 13-3-19.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import "UserLoginChargedViewController.h"
#import "AboutUsViewController.h"
#import "ResponseViewController.h"


@implementation UserLoginChargedViewController


//点击左导航条触发的动作
- (void)responseLeft:(id)button {
    [self.navigationController popViewControllerAnimated:YES];
}

//统一设置头部导航条
- (void)SET_HEADER_NAVIGATION {
    [self.navigationController.navigationBar
            setBackgroundImage:[UIImage imageNamed:@"navi_bg_height_1.png"]
                 forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setContentMode:UIViewContentModeScaleToFill];

    self.navigationItem.title = @"个人中心";

    //part1:导航栏-->  1.1 左边的导航条
    UIButton *left_btn = [UIButton buttonWithType:UIButtonTypeCustom];
    left_btn.frame = CGRectMake(0, 0, 61, 30);
    [left_btn setTitle:@"返回" forState:UIControlStateNormal];
    left_btn.titleLabel.font = [UIFont systemFontOfSize:15.0];
    left_btn.titleLabel.textAlignment = (NSTextAlignment) UITextAlignmentCenter;
    [left_btn setBackgroundImage:[UIImage imageNamed:@"back_61_30"] forState:UIControlStateNormal];
    [left_btn addTarget:self action:@selector(responseLeft:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *left_barBtn = [[[UIBarButtonItem alloc] initWithCustomView:left_btn] autorelease];
    self.navigationItem.leftBarButtonItem = left_barBtn;

}

- (void)loadView {
    [super loadView];
    [self SET_HEADER_NAVIGATION];//统一设置头部导航条
    [self.view setBackgroundColor:RGBACOLOR(41, 41, 41, 1)];

    //表格
    UITableView *tableView = [[[UITableView alloc] initWithFrame:CGRectMake(10, 130, 300, 202)] autorelease];
    tableView.frame = CGRectMake(10, 130, 300, 202);
    tableView.delegate = self;
    tableView.dataSource = self;
    tableView.backgroundColor = [UIColor clearColor];
    UIImageView *bgView = [[[UIImageView alloc] initWithFrame:CGRectMake(10, 130, 300, 202)] autorelease];
    bgView.image = [UIImage imageNamed:@"bg_usercenter.png"];
    tableView.backgroundView = bgView;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:tableView];
    //企业图标
    ((UIImageView *) [self.view viewWithTag:1005]).image = [UIImage imageNamed:@"ssports_logo.png"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


//点击某行记录会触发的事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    int row = indexPath.row;
    NSString *text = nil;
    UIViewController *controller = nil;
    if (row == 0) {
        text = @"关于我们";
        controller = [[[AboutUsViewController alloc]
                initWithNibName:@"AboutUsViewController" bundle:nil] autorelease];
        ((AboutUsViewController *) controller).fromStr = @"个人中心";
    }
    if (row == 1) {
        text = @"意见反馈";
        controller = [[[ResponseViewController alloc]
                initWithNibName:@"ResponseViewController" bundle:nil] autorelease];
        ((ResponseViewController *) controller).fromString = @"个人中心";
    }
    if (row == 2) {
        text = @"给我评分";
    }
    if (row == 3) {
        text = @"版本更新";
    }
    if (controller != nil) {
        [self.navigationController pushViewController:controller animated:YES];
    }

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 4;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                    reuseIdentifier:@"BaseCell"] autorelease];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                       reuseIdentifier:@"BaseCell"] autorelease];
    }
    cell.selectionStyle = (UITableViewCellSelectionStyle) UITableViewCellSeparatorStyleNone;
    int row = indexPath.row;
    UILabel *label = [[[UILabel alloc] initWithFrame:CGRectMake(13, 16, 100, 25)] autorelease];

    if (row == 0) {
        label.text = @"关于我们";
    }
    if (row == 1) {
        label.text = @"意见反馈";
    }
    if (row == 2) {
        label.text = @"给我评分";
    }
    if (row == 3) {
        label.text = @"版本更新";
    }

    [label setFont:[UIFont systemFontOfSize:20]]; //字体
    label.textColor = RGBACOLOR(41, 41, 41, 1);
    label.textAlignment = (NSTextAlignment) UITextAlignmentLeft;
    label.backgroundColor = [UIColor clearColor];
    [cell addSubview:label];
    UIImage *img = [UIImage imageNamed:@"arrow_usercenter.png"];
    UIImageView *imgView = [[[UIImageView alloc] initWithImage:img] autorelease];
    imgView.frame = CGRectMake(280, 21, 10, 16);
    [cell addSubview:imgView];
    if (row != 3) {
        img = [UIImage imageNamed:@"filter_usercenter.png"];
        imgView = [[[UIImageView alloc] initWithImage:img] autorelease];
        imgView.frame = CGRectMake(14, 50, 275, 2);
        [cell addSubview:imgView];
    }
    return cell;
}


@end